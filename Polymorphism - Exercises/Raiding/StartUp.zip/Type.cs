﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding
{
    public enum Type
    {
        Druid,
        Paladin,
        Rogue,
        Warrior

    }
}
